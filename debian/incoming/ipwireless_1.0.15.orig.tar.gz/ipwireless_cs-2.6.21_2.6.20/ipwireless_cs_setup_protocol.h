/*
 * IPWireless 3G PCMCIA Network Driver
 *
 * Original code
 *   by Stephen Blackheath <stephen@blacksapphire.com>,
 *      Ben Martel <benm@symmetric.co.nz>
 *
 * Copyrighted as follows:
 *   Copyright (C) 2004 by Symmetric Systems Ltd (NZ)
 *
 * Various driver changes and rewrites, port to new kernels
 *   Copyright (C) 2006-2007 Jiri Kosina
 */

#ifndef _IPWIRELESS_CS_SETUP_PROTOCOL_H_
#define _IPWIRELESS_CS_SETUP_PROTOCOL_H_

#include <linux/types.h>

/* Version of the setup protocol and transport protocols */
#define TL_SETUP_VERSION		1

#define TL_SETUP_VERSION_QRY_TMO	1000
#define TL_SETUP_MAX_VERSION_QRY	30

/* Message numbers 0-9 are obsoleted. The must not be reused! */
#define TL_SETUP_SIGNO_GET_VERSION_QRY	10
#define TL_SETUP_SIGNO_GET_VERSION_RSP	11
#define TL_SETUP_SIGNO_CONFIG_MSG	12
#define TL_SETUP_SIGNO_CONFIG_DONE_MSG	13
#define TL_SETUP_SIGNO_OPEN_MSG		14
#define TL_SETUP_SIGNO_CLOSE_MSG	15

#define TL_SETUP_SIGNO_INFO_MSG     20
#define TL_SETUP_SIGNO_INFO_MSG_ACK 21

#define TL_SETUP_SIGNO_REBOOT_MSG      22
#define TL_SETUP_SIGNO_REBOOT_MSG_ACK  23

/* Syncronous start-messages */
typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_GET_VERSION_QRY */
} __attribute__ ((__packed__)) TlSetupGetVersionQry;

typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_GET_VERSION_RSP */
	u_char version;		/* TL_SETUP_VERSION */
} __attribute__ ((__packed__)) TlSetupGetVersionRsp;

typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_CONFIG_MSG */
	u_char portNo;
	u_char prioData;
	u_char prioCtrl;
} __attribute__ ((__packed__)) TlSetupConfigMsg;

typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_CONFIG_DONE_MSG */
} __attribute__ ((__packed__)) TlSetupConfigDoneMsg;

/* Asyncronous messages */
typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_OPEN_MSG */
	u_char portNo;
} __attribute__ ((__packed__)) TlSetupOpenMsg;

typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_CLOSE_MSG */
	u_char portNo;
} __attribute__ ((__packed__)) TlSetupCloseMsg;

/* Driver type  - for use in TlSetupInfoMsg.driverType */
#define COMM_DRIVER     0
#define NDISWAN_DRIVER  1
#define NDISWAN_DRIVER_MAJOR_VERSION  2
#define NDISWAN_DRIVER_MINOR_VERSION  0

/* it should not matter when this message comes over as we just store the results and send the ACK. */
typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_INFO_MSG */
	u_char driverType;
	u_char majorVersion;
	u_char minorVersion;
} __attribute__ ((__packed__)) TlSetupInfoMsg;

typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_INFO_MSG_ACK */
} __attribute__ ((__packed__)) TlSetupInfoMsgAck;

typedef struct {
	u_char sigNo;		/* TL_SETUP_SIGNO_REBOOT_MSG_ACK */
} __attribute__ ((__packed__)) TlSetupRebootMsgAck;

/* Define a union of all the msgs that the driver can receive from the card.*/
typedef union {
	u_char sigNo;
	TlSetupGetVersionRsp VersRspMsg;
	TlSetupOpenMsg OpenMsg;
	TlSetupCloseMsg CloseMsg;
	TlSetupInfoMsg InfoMsg;
	TlSetupInfoMsgAck InfoMsgAck;
} __attribute__ ((__packed__)) SETUP_RX_MSG, *PSETUP_RX_MSG;

/* Define a union of all the msgs that the driver can send to the card. 
 * This will then represent the max msg that can be sent by the driver to the card
 */
typedef union {
	u_char sigNo;
	TlSetupGetVersionQry QryMsg;
	TlSetupConfigMsg ConfigMsg;
	TlSetupConfigDoneMsg ConfigDoneMsg;
	TlSetupOpenMsg OpenMsg;
	TlSetupCloseMsg CloseMsg;
	TlSetupInfoMsg InfoMsg;
	TlSetupRebootMsgAck RebootMsgAck;
} __attribute__ ((__packed__)) SETUP_TX_MSG, *PSETUP_TX_MSG;

#endif				/* _IPWIRELESS_CS_SETUP_PROTOCOL_H_ */
