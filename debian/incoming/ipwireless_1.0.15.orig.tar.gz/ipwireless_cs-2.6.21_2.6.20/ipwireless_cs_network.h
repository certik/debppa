/*
 * IPWireless 3G PCMCIA Network Driver
 *
 * Original code
 *   by Stephen Blackheath <stephen@blacksapphire.com>,
 *      Ben Martel <benm@symmetric.co.nz>
 *
 * Copyrighted as follows:
 *   Copyright (C) 2004 by Symmetric Systems Ltd (NZ)
 *
 * Various driver changes and rewrites, port to new kernels
 *   Copyright (C) 2006-2007 Jiri Kosina
 */

#ifndef _IPWIRELESS_CS_NETWORK_H_
#define _IPWIRELESS_CS_NETWORK_H_

#include <linux/types.h>

struct ipw_network_t;
struct ipw_tty_t;
struct ipw_hardware_t;

/* Definitions of the different channels on the PCMCIA UE */
#define IPW_CHANNEL_RAS      0
#define IPW_CHANNEL_DIALLER  1
#define IPW_CHANNEL_CONSOLE  2
#define NO_OF_IPW_CHANNELS   5

void ipwireless_network_notify_control_line_change(struct ipw_network_t *, unsigned int,
							unsigned int, unsigned int);
void ipwireless_network_packet_received(struct ipw_network_t *, unsigned int, u_char *,
							unsigned int);
struct ipw_network_t *ipwireless_network_create(struct ipw_hardware_t *);
void ipwireless_network_free(struct ipw_network_t *);
void ipwireless_associate_network_tty(struct ipw_network_t *, unsigned int, struct ipw_tty_t *tty);
void ipwireless_disassociate_network_ttys(struct ipw_network_t *, unsigned int);
void ipwireless_ppp_open(struct ipw_network_t *);

void ipwireless_ppp_close(struct ipw_network_t *);
int ipwireless_ppp_channel_index(struct ipw_network_t *);
int ipwireless_ppp_unit_number(struct ipw_network_t *);

int ipwireless_dump_network_state(char *p, struct ipw_network_t *network);

#endif
