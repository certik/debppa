/*
 * IPWireless 3G PCMCIA Network Driver
 *
 * Original code
 *   by Stephen Blackheath <stephen@blacksapphire.com>,
 *      Ben Martel <benm@symmetric.co.nz>
 *
 * Copyrighted as follows:
 *   Copyright (C) 2004 by Symmetric Systems Ltd (NZ)
 *
 * Various driver changes and rewrites, port to new kernels
 *   Copyright (C) 2006-2007 Jiri Kosina
 */

#ifndef _IPWIRELESS_CS_HARDWARE_H_
#define _IPWIRELESS_CS_HARDWARE_H_

#include <linux/types.h>
#include <linux/sched.h>
#include <linux/interrupt.h>

#define IPWIRELESS_IOMEM __iomem

#define IPW_CONTROL_LINE_CTS 0x0001
#define IPW_CONTROL_LINE_DCD 0x0002
#define IPW_CONTROL_LINE_DSR 0x0004
#define IPW_CONTROL_LINE_RI  0x0008
#define IPW_CONTROL_LINE_DTR 0x0010
#define IPW_CONTROL_LINE_RTS 0x0020

struct pt_regs;
struct ipw_config_t;
struct ipw_hardware_t;
struct ipw_network_t;

struct ipw_hardware_t *ipwireless_hardware_create(struct ipw_config_t *);
void ipwireless_hardware_free(struct ipw_hardware_t *);
irqreturn_t ipwireless_interrupt(int, void *, struct pt_regs *);
void ipwireless_setDTR(struct ipw_hardware_t *, unsigned int, int);
void ipwireless_setRTS(struct ipw_hardware_t *, unsigned int, int);
typedef void (*ipw_packet_sent_callback_t) (void *, unsigned int);
void ipwireless_send_packet(struct ipw_hardware_t *, unsigned int, u_char *,
			    unsigned int, ipw_packet_sent_callback_t,
			    void *);
void ipwireless_associate_network(struct ipw_hardware_t *, struct ipw_network_t *);
void ipwireless_stop_interrupts(struct ipw_hardware_t *);
typedef void (*ipw_reboot_callback_t) (void *);
void ipwireless_init_hardware1(struct ipw_hardware_t *, unsigned int,
			       void IPWIRELESS_IOMEM *, void IPWIRELESS_IOMEM *,
			       int, ipw_reboot_callback_t, void *);
void ipwireless_init_hardware2(struct ipw_hardware_t *);
void ipwireless_sleep(u_int tenths);
int ipwireless_dump_hardware_state(char *p, struct ipw_hardware_t *hw);

#endif
