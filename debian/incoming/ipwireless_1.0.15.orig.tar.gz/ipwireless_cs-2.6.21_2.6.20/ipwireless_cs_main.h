/*
 * IPWireless 3G PCMCIA Network Driver
 *
 * Original code
 *   by Stephen Blackheath <stephen@blacksapphire.com>,
 *      Ben Martel <benm@symmetric.co.nz>
 *
 * Copyrighted as follows:
 *   Copyright (C) 2004 by Symmetric Systems Ltd (NZ)
 *
 * Various driver changes and rewrites, port to new kernels
 *   Copyright (C) 2006-2007 Jiri Kosina
 */

#ifndef _IPWIRELESS_CS_H_
#define _IPWIRELESS_CS_H_

#include <linux/autoconf.h>
#include <linux/version.h>
#include <linux/types.h>
#include <linux/sched.h>
#include <pcmcia/cs_types.h>
#include <pcmcia/cs.h>
#include <pcmcia/cistpl.h>
#include <pcmcia/ds.h>

#include "ipwireless_cs_hardware.h"

#define IPWIRELESS_PCCARD_NAME  	"ipwireless_cs"
#define IPWIRELESS_PCMCIA_VERSION	"1.0.15-jikos2"
#define IPWIRELESS_PCMCIA_AUTHOR        "Stephen Blackheath, Ben Martel and Jiri Kosina"

#define IPWIRELESS_TX_QUEUE_SIZE  262144
#define IPWIRELESS_RX_QUEUE_SIZE  262144

#define IPWIRELESS_STATE_DEBUG

struct ipw_hardware_t;
struct ipw_network_t;
struct ipw_tty_t;

typedef struct ipw_config_t {
	char phone_number[129];
} ipw_config_t;

typedef struct ipw_dev_t {
	/* Linux PCMCIA structure */
	struct pcmcia_device *link;
	int isV2Card;
	window_handle_t handleAM;
	void IPWIRELESS_IOMEM *attrMemory;
	window_handle_t handleCM;
	void IPWIRELESS_IOMEM *commonMemory;
	dev_node_t nodes[4];
	/* Reference to attribute memory, containing CIS data */
	void *attribute_memory;

	/* Hardware context */
	struct ipw_hardware_t *hardware;
	/* Network layer context */
	struct ipw_network_t *network;	
	/* TTY device context */
	struct ipw_tty_t *tty;
	struct work_struct work_reboot;
} ipw_dev_t;

typedef struct pcmcia_device dev_link_t;

/* Options configurable through the proc filesystem. */
extern __u16 ipwireless_cs_debug;
extern __u16 ipwireless_cs_vendor;
extern __u16 ipwireless_cs_loopback;
extern __u16 ipwireless_cs_out_queue;

#endif
