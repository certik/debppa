/*
 * IPWireless 3G PCMCIA Network Driver
 *
 * Original code
 *   by Stephen Blackheath <stephen@blacksapphire.com>,
 *      Ben Martel <benm@symmetric.co.nz>
 *
 * Copyrighted as follows:
 *   Copyright (C) 2004 by Symmetric Systems Ltd (NZ)
 *
 * Various driver changes and rewrites, port to new kernels
 *   Copyright (C) 2006-2007 Jiri Kosina
 */

#include <linux/autoconf.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/interrupt.h>
#include <linux/list.h>
#include <asm/io.h>
#include <asm/irq.h>

#include "ipwireless_cs_hardware.h"
#include "ipwireless_cs_setup_protocol.h"
#include "ipwireless_cs_network.h"
#include "ipwireless_cs_main.h"

/* Function prototypes */
static void do_setup_hardware(struct ipw_hardware_t *ipw);
static void handle_received_SETUP_packet(struct ipw_hardware_t *ipw,
					 unsigned int address,
					 u_char * data, int len,
					 int is_last);
static void ipwireless_setup_timer(unsigned long data);
static void do_io(struct ipw_hardware_t *hw);
static void do_close_hardware(struct ipw_hardware_t *hw);
static int is_card_present(struct ipw_hardware_t *hw);
static void handle_received_CTRL_packet(struct ipw_hardware_t * hw, unsigned int channelIdx, u_char * data, int len);

/*#define TIMING_DIAGNOSTICS*/

#ifdef TIMING_DIAGNOSTICS

static unsigned long last_report_time;
static unsigned long read_time;
static unsigned long write_time;
static unsigned long read_bytes;
static unsigned long write_bytes;
static void report_timing(void)
{
	unsigned long since = jiffies - last_report_time;
	/* If it's been more than one second... */
	if (since >= HZ) {
		int first = last_report_time == 0;
		last_report_time = jiffies;
		if (!first) {
			printk(KERN_INFO IPWIRELESS_PCCARD_NAME
			       ": %u us elapsed - read %lu bytes in %u us, wrote %lu bytes in %u us\n",
			       jiffies_to_usecs(since), read_bytes,
			       jiffies_to_usecs(read_time), write_bytes,
			       jiffies_to_usecs(write_time));
		}
		read_time = write_time = 0;
		read_bytes = write_bytes = 0;
	}
}
#endif


/* Imported IPW definitions */

#define LL_MTU_V1 318
#define LL_MTU_V2 250
#define LL_MTU_MAX (LL_MTU_V1>LL_MTU_V2?LL_MTU_V1:LL_MTU_V2)

#define PRIO_DATA  2
#define PRIO_CTRL  1
#define PRIO_SETUP 0

/* Addresses */
#define ADDR_SETUP_PROT 0

/* Protocol ids */
enum {
	/* Identifier for the Com Data protocol */
	TL_PROTOCOLID_COM_DATA = 0,

	/* Identifier for the Com Control protocol */
	TL_PROTOCOLID_COM_CTRL = 1,

	/* Identifier for the Setup protocol */
	TL_PROTOCOLID_SETUP = 2
};
/* Number of bytes in NL packet header (can not do 
 * sizeof(NLPacketHeader) since it's a bitfield) */
#define NL_FIRST_PACKET_HEADER_SIZE        3

/* Number of bytes in NL packet header (can not do 
 * sizeof(NLPacketHeader) since it's a bitfield) */
#define NL_FOLLOWING_PACKET_HEADER_SIZE    1

typedef struct NLFirstPacketHeader {
#if defined(__BIG_ENDIAN)
	unsigned int firstLast:2;
	unsigned int address:3;
	unsigned int protocol:3;
#else
	unsigned int protocol:3;
	unsigned int address:3;
	unsigned int firstLast:2;
#endif
	u_char length_lsb;
	u_char length_msb;
} __attribute__ ((__packed__)) NLFirstPacketHeader;

typedef struct NLPacketHeader {
#if defined(__BIG_ENDIAN)
	unsigned int firstLast:2;
	unsigned int address:3;
	unsigned int protocol:3;
#else
	unsigned int protocol:3;
	unsigned int address:3;
	unsigned int firstLast:2;
#endif
} __attribute__ ((__packed__)) NLPacketHeader;

/* Value of 'firstLast' above */
#define NL_INTERMEDIATE_PACKET    0x0
#define NL_LAST_PACKET            0x1
#define NL_FIRST_PACKET           0x2

typedef union NLPacket {
	/* Network packet header of the first packet (yes, a special case!!!!) */
	struct NLFirstPacketHeader hdrFirst;
	/* Network packet header of the following packets (if any) */
	struct NLPacketHeader hdr;
	/* Complete network packet (header + data) */
	u_char rawpkt[LL_MTU_MAX];
} __attribute__ ((__packed__)) NLPacket, *PNLPacket;

#define HW_VERSION_UNKNOWN -1
#define HW_VERSION_1 1
#define HW_VERSION_2 2

/* IPW I/O ports */
#define IOIER 0x00		/* Interrupt Enable Register */
#define IOIR  0x02		/* Interrupt Source/ACK register */
#define IODCR 0x04		/* Data Control Register */
#define IODRR 0x06		/* Data Read Register */
#define IODWR 0x08		/* Data Write Register */
#define IOESR 0x0A		/* Embedded Driver Status Register */
#define IORXR 0x0C		/* Rx Fifo Register (Host to Embedded) */
#define IOTXR 0x0E		/* Tx Fifo Register (Embedded to Host) */

/* I/O ports and bit definitions for version 1 of the hardware */

/* IER bits*/
#define IER_RXENABLED   ((u_short) 0x1)
#define IER_TXENABLED   ((u_short) 0x2)

/* ISR bits */
#define IR_RXINTR       ((u_short) 0x1)
#define IR_TXINTR       ((u_short) 0x2)

/* DCR bits */
#define DCR_RXDONE      ((u_short) 0x1)
#define DCR_TXDONE      ((u_short) 0x2)
#define DCR_RXRESET     ((u_short) 0x4)
#define DCR_TXRESET     ((u_short) 0x8)

/* I/O ports and bit definitions for version 2 of the hardware */

typedef struct {
	u_short PCCOR;		/* Configuration Option Register */
	u_short PCCSR;		/* Configuration and Status Register */
	u_short PCPRR;		/* Pin Replacemant Register */
	u_short PCSCR;		/* Socket and Copy Register */
	u_short PCESR;		/* Extendend Status Register */
	u_short PCIOB;		/* I/O Base Register */
} MEMCCR;

typedef struct {
	u_short MemTX_OLD;	/* TX Register (R/W) */
	u_short Pad1;
	u_short MemRXDone;	/* RXDone Register (R/W) */
	u_short Pad2;
	u_short MemRX;		/* RX Register (R/W) */
	u_short Pad3;
	u_short MemPCIntAck;	/* PC interrupt Ack Register (W) */
	u_short Pad4;
	u_long MemCardPresent;	/* Mask for Host to check (R) for CARD_PRESENT_VALUE */
	u_short MemTX_NEW;	/* TX2 (new) Register (R/W) */
} MEMINFREG;

#define IODMADPR 0x00		/* DMA Data Port Register (R/W) */

#define CARD_PRESENT_VALUE ((u_long)0xBEEFCAFEUL)

#define MEMTX_TX                       0x0001
#define MEMRX_RX                       0x0001
#define MEMRX_RX_DONE                  0x0001
#define MEMRX_PCINTACKK                0x0001
#define MEMRX_MEMSPURIOUSINT           0x0001

#define NL_NUM_OF_PRIORITIES       3
#define NL_NUM_OF_PROTOCOLS        3
#define NL_NUM_OF_ADDRESSES        NO_OF_IPW_CHANNELS

typedef struct ipw_assembler_t {
	struct ipw_rx_packet_t *packet;
} ipw_assembler_t;

typedef struct ipw_hardware_t {
	unsigned int base_port;
	short hwVersion;
	unsigned short llMTU;
	struct ipw_config_t config;
	spinlock_t spinlock;

	int initializing;
	int init_loops;
	struct timer_list setup_timer;

	int tx_ready;
	struct list_head tx_queue[NL_NUM_OF_PRIORITIES];
	/* True if any packets are queued for transmission */
	int tx_queued;

	int rx_bytes_queued;
	struct list_head rx_queue;
	/* Pool of rx_packet structures that are not currently used. */
	struct list_head rx_pool;
	/* True if reception of data is blocked while userspace processes it. */
	int blocking_rx;
	/* True if there is RX data ready on the hardware. */
	int rx_ready;
	u_short last_memtx_serial;
	/* Newer versions of the V2 card firmware send serial numbers in the MemTX 
	 * register. 'serial_number_detected' is set true when we detect a
	 * non-zero serial number (indicating the new firmware).  Thereafter,
	 * the driver can safely ignore the Timer Recovery re-sends to avoid
	 * out-of-sync problems.
	 */
	int serial_number_detected;
	struct work_struct work_rx;

	/* True if we are to send the set-up data to the hardware. */
	int to_setup;

	/* Card has been removed */
	int removed;
	/* Saved irq value when we disable the interrupt. */
	int irq;
	/* True if some thread is performing hardware I/O */
	int doing_io;
	/* True if this driver is shutting down. */
	int shutting_down;
	/* Modem control lines */
	unsigned int control_lines[NL_NUM_OF_ADDRESSES];
	ipw_assembler_t packet_assembler[NL_NUM_OF_ADDRESSES];

	struct tasklet_struct tasklet;
	int tasklet_pending;

	/* The handle for the network layer, for the sending of events to it. */
	struct ipw_network_t *network;
	MEMINFREG IPWIRELESS_IOMEM *memInfReg;
	MEMCCR IPWIRELESS_IOMEM *memCCR;
	int bad_interrupt_count;
	ipw_reboot_callback_t reboot_callback;
	void *reboot_callback_data;

	u_short *MemTX;
} ipw_hardware_t;

struct ipw_tx_packet_t;

typedef void (*packet_sent_callback_t) (struct ipw_hardware_t * ipw,
					struct ipw_tx_packet_t * packet);

/* Packet info structure for tx packets. 
 * Note: not all the fields defined here are required for all protocols */
typedef struct ipw_tx_packet_t {
	struct list_head queue;
	/* channel idx + 1 */
	u_char dest_addr;
	/* SETUP, CTRL or DATA */
	u_char protocol;
	/* Length of data block, which starts at the end of this structure */
	u_short length;
	/* Function to call upon packet completion. */
	packet_sent_callback_t packet_sent_callback;
	/* Sending state */
	/* Offset of where we've sent up to so far */
	u_long offset;
	/* Count of packet fragments, starting at 0 */
	int fragment_count;

	ipw_packet_sent_callback_t external_callback;
	void *external_callback_data;
} ipw_tx_packet_t;

/* Signals from DTE */
typedef enum ComCtrl_DTESignal { ComCtrl_RTS = 0, ComCtrl_DTR = 1
} ComCtrl_DTESignal;

/* Signals from DCE */
typedef enum ComCtrl_DCESignal { ComCtrl_CTS = 2, ComCtrl_DCD =
	    3, ComCtrl_DSR = 4, ComCtrl_RI = 5
} ComCtrl_DCESignal;

typedef struct ipw_control_packet_body_t {

	/* ComCtrl_DTESignal or ComCtrl_DCESignal */
	u_char sigNo;
	/* ComCtrl_SET(0) or ComCtrl_CLEAR(1) */
	u_char value;
} __attribute__ ((__packed__)) ipw_control_packet_body_t;

typedef struct ipw_control_packet_t {
	struct ipw_tx_packet_t packet;
	struct ipw_control_packet_body_t body;
} ipw_control_packet_t;

typedef struct ipw_rx_packet_t {
	struct list_head queue;
	unsigned int capacity;
	unsigned int length;
	unsigned int protocol;
	unsigned int channelIdx;
} ipw_rx_packet_t;


#ifdef IPWIRELESS_STATE_DEBUG
int ipwireless_dump_hardware_state(char *p, ipw_hardware_t * hw)
{
	int idx = 0;

	idx +=
	    sprintf(p + idx, "debug: initializing=%d\n", hw->initializing);
	idx += sprintf(p + idx, "debug: tx_ready=%d\n", hw->tx_ready);
	idx += sprintf(p + idx, "debug: tx_queued=%d\n", hw->tx_queued);
	idx += sprintf(p + idx, "debug: rx_ready=%d\n", hw->rx_ready);
	idx +=
	    sprintf(p + idx, "debug: rx_bytes_queued=%d\n",
		    hw->rx_bytes_queued);
	idx +=
	    sprintf(p + idx, "debug: blocking_rx=%d\n", hw->blocking_rx);
	idx += sprintf(p + idx, "debug: removed=%d\n", hw->removed);
	idx += sprintf(p + idx, "debug: doing_io=%d\n", hw->doing_io);
	idx +=
	    sprintf(p + idx, "debug: tasklet_pending=%d\n",
		    hw->tasklet_pending);
	idx +=
	    sprintf(p + idx, "debug: hardware.shutting_down=%d\n",
		    hw->shutting_down);
	return idx;
}
#endif



static char *data_type(const u_char * buf, unsigned length)
{
	NLPacketHeader *hdr = (NLPacketHeader *) buf;
	if (length == 0)
		return "     ";

	if (hdr->firstLast & NL_FIRST_PACKET) {
		if (hdr->protocol == TL_PROTOCOLID_COM_DATA)
			return "DATA ";
		if (hdr->protocol == TL_PROTOCOLID_COM_CTRL)
			return "CTRL ";
		if (hdr->protocol == TL_PROTOCOLID_SETUP)
			return "SETUP";
		return "???? ";
	} else
		return "     ";
}

#define DUMP_MAX_BYTES 64

/**
 * Send a fragment of a packet.
 */
static int
do_send_fragment(ipw_hardware_t * hw, const u_char * data, unsigned length)
{
	int i;

#ifdef TIMING_DIAGNOSTICS
	unsigned long start_time = jiffies;
#endif

	/* If length is 0, then there is no work to do - return success. */
	if (length == 0)
		return 0;

	/* If length is greater than our MTU, then we fail. */
	if (length > hw->llMTU)
		return -1;

	if (ipwireless_cs_debug) {
		char buf[DUMP_MAX_BYTES * 4 + 16];
		int i;
		buf[0] = 0;
		for (i = 0; i < length && i < DUMP_MAX_BYTES; i++)
			sprintf(buf + strlen(buf), " %x ",
				(unsigned int) data[i]);
		if (i > DUMP_MAX_BYTES)
			strcat(buf, "...");
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": send fragment %s%s\n", data_type(data, length),
		       buf);
	}

	if (hw->hwVersion == HW_VERSION_1) {
		outw((u_short) length, hw->base_port + IODWR);

		for (i = 0; i < length; i += 2) {
			u_short d = data[i];
			if (i + 1 < length)
				d |= (((u_short) data[i + 1]) << 8);
			outw(d, hw->base_port + IODWR);
		}

		outw(DCR_TXDONE, hw->base_port + IODCR);
	} else if (hw->hwVersion == HW_VERSION_2) {
		outw((u_short) length, hw->base_port + IODMADPR);

		for (i = 0; i < length; i += 2) {
			u_short d = data[i];
			if (i + 1 < length)
				d |= (((u_short) data[i + 1]) << 8);
			outw(d, hw->base_port + IODMADPR);
		}
		while ((i & 3) != 2) {
			outw((u_short) 0xDEAD, hw->base_port + IODMADPR);
			i += 2;
		}
		iowrite16(MEMRX_RX, &hw->memInfReg->MemRX);
	}
#ifdef TIMING_DIAGNOSTICS
	write_time += (jiffies - start_time);
	write_bytes += length + 2;
	report_timing();
#endif

	return 0;
}

/* Called with spinlock in force.  It unlocks, then re-locks it. */
static int do_send_packet(ipw_hardware_t * hw, ipw_tx_packet_t * packet)
{
	u_short fragment_data_len;
	u_short data_left = packet->length - packet->offset;
	NLPacket pkt;
	u_short header_size;

	spin_unlock_irq(&hw->spinlock);
	header_size =
	    packet->fragment_count ==
	    0 ? NL_FIRST_PACKET_HEADER_SIZE :
	    NL_FOLLOWING_PACKET_HEADER_SIZE;
	fragment_data_len = (u_short) hw->llMTU - header_size;
	if (data_left < fragment_data_len)
		fragment_data_len = data_left;

	pkt.hdrFirst.protocol = packet->protocol;
	pkt.hdrFirst.address = packet->dest_addr;
	pkt.hdrFirst.firstLast = 0;

	/* First packet? */
	if (packet->fragment_count == 0) {
		pkt.hdrFirst.firstLast |= NL_FIRST_PACKET;
		pkt.hdrFirst.length_lsb = (u_char) packet->length;
		pkt.hdrFirst.length_msb = (u_char) (packet->length >> 8);
	}

	memcpy(pkt.rawpkt + header_size,
	       ((u_char *) packet) + sizeof(ipw_tx_packet_t) +
	       packet->offset, fragment_data_len);
	packet->offset += fragment_data_len;
	packet->fragment_count++;

	/* Last packet? (May also be first packet.) */
	if (packet->offset == packet->length)
		pkt.hdrFirst.firstLast |= NL_LAST_PACKET;
	do_send_fragment(hw, pkt.rawpkt, header_size + fragment_data_len);

	/* If this packet has unsent data, then re-queue it. */
	if (packet->offset < packet->length) {
		spin_lock_irq(&hw->spinlock);
		/* Re-queue it at the head of the highest priority queue so it goes before
		 * all other packets */
		list_add(&packet->queue, &hw->tx_queue[0]);
	} else {
		(*packet->packet_sent_callback) (hw, packet);
		spin_lock_irq(&hw->spinlock);
	}

	return 0;
}

/*
 * Free the specified packet.  Can be used as a 'packet_sent_callback'
 * to free the packet once it has been sent.
 */
static void free_packet(ipw_hardware_t * hw, struct ipw_tx_packet_t *packet)
{
	kfree(packet);
}

/*
 * Free the specified packet.  Can be used as a 'packet_sent_callback'
 * to free the packet once it has been sent.
 */
static void free_packet_and_callback(ipw_hardware_t * hw, struct ipw_tx_packet_t *packet)
{
	if (packet->external_callback != NULL) {
		(*packet->external_callback) (packet->external_callback_data,
					      packet->length);
	}
	kfree(packet);
}

/*!
 * If 'packet' is NULL, then this function allocates a new packet, setting its
 * length to 0 and ensuring it has the specified minimum amount of free space.
 * 
 * If 'packet' is not NULL, then this function enlarges it if it doesn't
 * have the specified minimum amount of free space.
 */
static ipw_rx_packet_t *pool_allocate(ipw_hardware_t * hw,
				      ipw_rx_packet_t * packet,
				      int minimum_free_space)
{
	if (packet == NULL) {
		/* If this is the first fragment, then we will need to fetch a packet to
		 * put it in. */
		spin_lock_irq(&hw->spinlock);
		/* If we have one in our pool, then pull it out. */
		if (!list_empty(&hw->rx_pool)) {
			packet = list_entry(hw->rx_pool.next, ipw_rx_packet_t, queue);
			list_del_init(&packet->queue);
			spin_unlock_irq(&hw->spinlock);
		}
		/* Otherwise allocate a new one. */
		else {
			static int min_capacity = 256;
			int new_capacity;
			spin_unlock_irq(&hw->spinlock);
			new_capacity =
			    minimum_free_space > min_capacity ? minimum_free_space : min_capacity;
			packet = kmalloc(sizeof(ipw_rx_packet_t) + new_capacity, GFP_ATOMIC);
			packet->capacity = new_capacity;
		}
		packet->length = 0;
	}

	/* If this packet does not have sufficient capacity for the data we want to
	 * add, then make it bigger. */
	if (packet->length + minimum_free_space > packet->capacity) {
		ipw_rx_packet_t *old_packet = packet;
		packet = kmalloc(sizeof(ipw_rx_packet_t) + 
				old_packet->length + minimum_free_space, GFP_ATOMIC);
		memcpy(packet, old_packet, sizeof(ipw_rx_packet_t) + old_packet->length);
		packet->capacity = old_packet->length + minimum_free_space;
		kfree(old_packet);
	}

	return packet;
}

static void pool_free(ipw_hardware_t * hw, ipw_rx_packet_t * packet)
{
	static int ticker;

	/* Every now and again we release one instead of pushing it back onto the
	 * pool.  This isn't perfectly efficient, but it prevents us wasting memory. */
	if ((ticker++ & 0x3f) == 0)
		kfree(packet);
	else
		list_add_tail(&packet->queue, &hw->rx_pool);
}

static void queue_received_packet(ipw_hardware_t* hw, unsigned int protocol, 
		unsigned int address, u_char* data, int length, int is_last)
{
	unsigned int channelIdx = address - 1;
	ipw_rx_packet_t* packet = NULL;

	/* Discard packet if channel index is out of range. */
	if (channelIdx >= NL_NUM_OF_ADDRESSES) {
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": data packet has bad address %d\n", address);
		return;
	}

	if (protocol == TL_PROTOCOLID_COM_DATA) {
		ipw_assembler_t* assem = &hw->packet_assembler[channelIdx];

		/* Create a new packet, or if this assembler already contains one, then
		 * make larger by 'length' bytes. */
		assem->packet = pool_allocate(hw, assem->packet, length);
		assem->packet->protocol = protocol;
		assem->packet->channelIdx = channelIdx;

		/* Append this packet data onto existing data. */
		memcpy((u_char*)assem->packet + sizeof(ipw_rx_packet_t) + assem->packet->length,
				data, length);
		assem->packet->length += length;
		if (is_last) {
			packet = assem->packet;
			assem->packet = NULL;
			hw->rx_bytes_queued += packet->length;  /* Count queued DATA bytes only */
		}
	}
	else {
		/* If it's a CTRL packet, don't assemble fragments - just queue it. */
		packet = pool_allocate(hw, NULL, length);
		packet->protocol = protocol;
		packet->channelIdx = channelIdx;
		memcpy((u_char*)packet + sizeof(ipw_rx_packet_t), data, length);
		packet->length = length;
	}


	/* If this is the last packet, then send the assembled packet on to the network layer. */
	if (packet != NULL) {
		spin_lock_irq(&hw->spinlock);
		list_add_tail(&packet->queue, &hw->rx_queue);
		/* Block reception of incoming packets if queue is full. */
		hw->blocking_rx =
		    hw->rx_bytes_queued >= IPWIRELESS_RX_QUEUE_SIZE;

		spin_unlock_irq(&hw->spinlock);
		schedule_work(&hw->work_rx);
	}
}

static void do_receive_data_work(struct work_struct *work_rx)
{
	struct ipw_hardware_t *hw =
	    container_of(work_rx, struct ipw_hardware_t, work_rx);
	struct list_head *p, *q;

	spin_lock_irq(&hw->spinlock);
	list_for_each_safe(p, q, &hw->rx_queue) {
		ipw_rx_packet_t *packet = list_entry(p, ipw_rx_packet_t, queue);
		if (hw->shutting_down)
			break;
		list_del_init(p);

		/* Note: ipwireless_network_packet_received must be called in a process
		   context (i.e. via schedule_work) because the tty output code can sleep
		   in the tty_flip_buffer_push call. */
		if (packet->protocol == TL_PROTOCOLID_COM_DATA) {
			if (hw->network != NULL) {  /* If the network hasn't been disconnected. */
				spin_unlock_irq(&hw->spinlock);
				ipwireless_network_packet_received(hw->network, packet->channelIdx,
						(u_char*)packet + sizeof(ipw_rx_packet_t), packet->length);
				spin_lock_irq(&hw->spinlock);
			}
			hw->rx_bytes_queued -= packet->length;  /* Count queued DATA bytes only */
		} else {
			spin_unlock_irq(&hw->spinlock);
			handle_received_CTRL_packet(hw, packet->channelIdx,
					(u_char*)packet + sizeof(ipw_rx_packet_t), packet->length);
			spin_lock_irq(&hw->spinlock);
		}
		pool_free(hw, packet);
		/* Unblock reception of incoming packets if queue is no longer full. */
		hw->blocking_rx = hw->rx_bytes_queued >= IPWIRELESS_RX_QUEUE_SIZE;
		if (hw->shutting_down)
			break;

		do_io(hw);
	}
	spin_unlock_irq(&hw->spinlock);
}

static void handle_received_CTRL_packet(struct ipw_hardware_t * hw,
					unsigned int channelIdx,
					u_char * data, int len)
{
	ipw_control_packet_body_t *body = (ipw_control_packet_body_t *) data;
	unsigned int changed_mask;

	if (len != sizeof(ipw_control_packet_body_t)) {
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": control packet was %d bytes - wrong size!\n",
		       len);
		return;
	}

	switch (body->sigNo) {
	case ComCtrl_CTS:
		changed_mask = IPW_CONTROL_LINE_CTS;
		break;
	case ComCtrl_DCD:
		changed_mask = IPW_CONTROL_LINE_DCD;
		break;
	case ComCtrl_DSR:
		changed_mask = IPW_CONTROL_LINE_DSR;
		break;
	case ComCtrl_RI:
		changed_mask = IPW_CONTROL_LINE_RI;
		break;
	default:
		changed_mask = 0;
	}

	if (changed_mask != 0) {
		if (body->value)
			hw->control_lines[channelIdx] |= changed_mask;
		else
			hw->control_lines[channelIdx] &= ~changed_mask;
		if (hw->network != NULL)
			ipwireless_network_notify_control_line_change(hw->network,
								      channelIdx,
								      hw->control_lines[channelIdx],
								      changed_mask);
	}
}

static void handle_received_packet(ipw_hardware_t * hw, NLPacket * packet,
				   u_short len)
{
	unsigned int protocol = packet->hdr.protocol;
	unsigned int address = packet->hdr.address;
	unsigned int header_length;
	u_char *data;
	unsigned int data_len;
	int is_last = packet->hdr.firstLast & NL_LAST_PACKET;

	if (packet->hdr.firstLast & NL_FIRST_PACKET) {
		header_length = NL_FIRST_PACKET_HEADER_SIZE;
	} else {
		header_length = NL_FOLLOWING_PACKET_HEADER_SIZE;
	}
	data = packet->rawpkt + header_length;
	data_len = len - header_length;
	switch (protocol) {
	case TL_PROTOCOLID_COM_DATA:
	case TL_PROTOCOLID_COM_CTRL:
		queue_received_packet(hw, protocol, address, data, data_len, is_last);
		break;
	case TL_PROTOCOLID_SETUP:
		handle_received_SETUP_packet(hw, address, data, data_len,
					     is_last);
		break;
	}
}

/*
 * Retrieve a packet from the IPW hardware.
 */
static void do_receive_packet(ipw_hardware_t * hw)
{
	u_short len;
	unsigned int i;
	u_char pkt[LL_MTU_MAX];
#ifdef TIMING_DIAGNOSTICS
	unsigned long start_time = jiffies;
#endif

	if (hw->hwVersion == HW_VERSION_1) {
		len = inw(hw->base_port + IODRR);
		if (len > hw->llMTU) {
			printk(KERN_INFO IPWIRELESS_PCCARD_NAME
			       ": received a packet of %d bytes - longer than the MTU!\n",
			       len);
			outw(DCR_RXDONE | DCR_RXRESET,
			     hw->base_port + IODCR);
			return;
		}

		for (i = 0; i < len; i += 2) {
			u_short data = inw(hw->base_port + IODRR);
			pkt[i] = (u_char) data;
			pkt[i + 1] = (u_char) (data >> 8);
		}
	} else {
		len = inw(hw->base_port + IODMADPR);
		if (len > hw->llMTU) {
			printk(KERN_INFO IPWIRELESS_PCCARD_NAME
			       ": received a packet of %d bytes - longer than the MTU!\n",
			       len);
			iowrite16(MEMRX_PCINTACKK,
				  &hw->memInfReg->MemPCIntAck);
			return;
		}

		for (i = 0; i < len; i += 2) {
			u_short data = inw(hw->base_port + IODMADPR);
			pkt[i] = (u_char) data;
			pkt[i + 1] = (u_char) (data >> 8);
		}

		while ((i & 3) != 2) {
			inw(hw->base_port + IODMADPR);
			i += 2;
		}
	}

	if (ipwireless_cs_debug) {
		char buf[DUMP_MAX_BYTES * 4 + 16];
		int i;
		buf[0] = 0;
		for (i = 0; i < len && i < DUMP_MAX_BYTES; i++)
			sprintf(buf + strlen(buf), " %x ",
				(unsigned int) pkt[i]);
		if (i > DUMP_MAX_BYTES)
			strcat(buf, "...");
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": recv fragment %s%s\n", data_type(pkt, len), buf);
	}

	handle_received_packet(hw, (NLPacket *) pkt, len);
	/* ACK reading */
	if (hw->hwVersion == HW_VERSION_1) {
		outw(DCR_RXDONE, hw->base_port + IODCR);
	} else {
		iowrite16(MEMRX_PCINTACKK, &hw->memInfReg->MemPCIntAck);
	}
#ifdef TIMING_DIAGNOSTICS
	read_time += (jiffies - start_time);
	read_bytes += len + 2;
	report_timing();
#endif
}

/*
 * Send queued packets. Must be called with spin_lock locked.
 * May be called either from a interrupt tasklet, or from a process context.
 */
static void do_io(ipw_hardware_t * hw)
{
	int no_data_sent = 0;

	/* If another thread is already performing I/O on the hardware,
	 * then we need not do it on this thread, so exit. */
	if (hw->doing_io || hw->shutting_down)
		return;

	/* Tell other threads we have exclusive access to the hardware. */
	hw->doing_io = 1;
	while (1) {
		int no_data_sent_last_time = no_data_sent;
		no_data_sent = 0;

		/* If we are to send setup data to the hardware... */
		if (hw->to_setup == 1) {
			hw->to_setup = 2;
			spin_unlock_irq(&hw->spinlock);
			do_setup_hardware(hw);
			spin_lock_irq(&hw->spinlock);
		} else
			/* If there is incoming data to be retrieved, retrieve it. */
		if (hw->rx_ready && !hw->blocking_rx) {
			hw->rx_ready--;
			spin_unlock_irq(&hw->spinlock);
			do_receive_packet(hw);
			spin_lock_irq(&hw->spinlock);
		} else if (hw->tx_queued && hw->tx_ready != 0) {
			int another_packet_to_send = 0;
			int priority;

			/* If we're initializing, don't send anything of higher priority than
			   PRIO_SETUP.  The network layer therefore need not care about hardware
			   initialization - any of its stuff will simply be queued until setup
			   is complete. */
			int priority_limit = (hw->to_setup || 
					hw-> initializing) ? PRIO_SETUP + 1 : NL_NUM_OF_PRIORITIES;

			hw->tx_ready--;

			no_data_sent = 1;
			for (priority = 0; priority < priority_limit;
			     priority++)
				if (!list_empty (&hw->tx_queue[priority])) {
					struct list_head *p = hw->tx_queue[priority].next;

					ipw_tx_packet_t *packet = list_entry(p, ipw_tx_packet_t, queue);
					list_del_init(p);

					no_data_sent = 0;

					/* do_send_packet() unlocks, then re-locks the spinlock. */
					do_send_packet(hw, packet);
					break;
				}

			/* Now that we've sent (or not sent) a packet, see if there's any more to
			 * send after that (include all data, including non-setup data if we are
			 * setting up. */
			for (priority = 0; priority < NL_NUM_OF_PRIORITIES;
			     priority++)
				if (!list_empty (&hw->tx_queue[priority])) {
					another_packet_to_send = 1;
					break;
				}

			/* If there are no more packets queued to be sent after the present one... */
			if (!another_packet_to_send) {
				hw->tx_queued = 0;
			}

			/* The logic above would produce an endless loop when hw->to_setup is non-zero,
			 * and there is non-setup data (>PRIO_SETUP) queued, but no PRIO_SETUP data.
			 * The if below protects against this. */
			if (no_data_sent && no_data_sent_last_time)
				break;
		}
		/* If we've run out of things to do, then stop looping. */
		else
			break;
	}
	hw->doing_io = 0;
}

static void ipwireless_do_tasklet(unsigned long hw_)
{
	ipw_hardware_t *hw = (ipw_hardware_t *) hw_;

	spin_lock_irq(&hw->spinlock);
	do_io(hw);
	hw->tasklet_pending = 0;
	spin_unlock_irq(&hw->spinlock);
}

/*!
 * @return true if the card is physically present.
 */
static int is_card_present(ipw_hardware_t * hw)
{
	if (hw->hwVersion == HW_VERSION_1)
		return inw(hw->base_port + IOIR) != (u_short) 0xFFFF;
	else
		return ioread32(&hw->memInfReg->MemCardPresent) ==
		    CARD_PRESENT_VALUE;
}

static irqreturn_t ipwireless_handle_v1_interrupt(int irq, ipw_hardware_t *hw)
{
	u_short irqn;
	u_short ack;

	irqn = inw(hw->base_port + IOIR);

	if (irqn == (u_short) 0xFFFF) {
		if (++hw->bad_interrupt_count >= 100) {
			/* It is necessary to disable the interrupt at this point, or the kernel
			 * hangs, interrupting repeatedly forever. */
			hw->irq = irq;
			hw->removed = 1;
			disable_irq_nosync(irq);
			printk(KERN_DEBUG IPWIRELESS_PCCARD_NAME
					": Mr. Fluffy is not happy!\n");
		}
		return IRQ_HANDLED;
	} else if (irqn != 0) {
		ack = 0;
		/* Transmit complete. */
		if (irqn & IR_TXINTR) {
			hw->tx_ready++;
			ack |= IR_TXINTR;
		}

		/* Received data */
		if (irqn & IR_RXINTR) {
			ack |= IR_RXINTR;
			hw->rx_ready++;
		}
		if (ack != 0) {
			outw(ack, hw->base_port + IOIR);

			/* Perform the I/O retrieval in a tasklet, because the ppp_generic
			   may be called from a tasklet, but not from a hardware interrupt. */
			if (!hw->tasklet_pending) {
				hw->tasklet_pending = 1;
				tasklet_schedule(&hw->tasklet);
			}
		}
		return IRQ_HANDLED;
	} else 
		return IRQ_NONE;

}

static irqreturn_t ipwireless_handle_v2_v3_interrupt(int irq, ipw_hardware_t *hw)
{
	int tx = 0;
	int rx = 0;
	int rx_repeat = 0;
	u_short memtx = ioread16(hw->MemTX);
	u_short memtx_serial;
	u_short memrxdone = ioread16(&hw->memInfReg->MemRXDone);

	/* check whether the interrupt was generated by ipwireless card */
	if (!(memtx & MEMTX_TX) && !(memrxdone & MEMRX_RX_DONE))
		return IRQ_NONE;

	/* See if the card is physically present. Note that while it is 
	 * powering up, it appears not to be present. */
	if (ioread32(&hw->memInfReg->MemCardPresent) != CARD_PRESENT_VALUE) {
		u_short csr = ioread16(&hw->memCCR->PCCSR);
		csr &= 0xfffd;
		iowrite16(csr, &hw->memCCR->PCCSR);
		return IRQ_HANDLED;
	}

	memtx_serial = memtx & (u_short) 0xff00;
	if (memtx & MEMTX_TX) {
		iowrite16(0, hw->MemTX);

		if (hw->serial_number_detected) {
			if (memtx_serial != hw->last_memtx_serial) {
				hw->last_memtx_serial = memtx_serial;
				hw->rx_ready++;
				rx = 1;
			} else
				rx_repeat = 1;	/* Ignore 'Timer Recovery' duplicates. */
		} else {
			/* If a non-zero serial number is seen, then enable serial number
			 * checking. */
			if (memtx_serial != 0) {
				hw->serial_number_detected = 1;
				printk(KERN_DEBUG IPWIRELESS_PCCARD_NAME
						": MemTX serial number detected\n");
			}
			hw->rx_ready++;
			rx = 1;
		}
	}
	if (memrxdone & MEMRX_RX_DONE) {
		iowrite16(0, &hw->memInfReg->MemRXDone);
		hw->tx_ready++;
		tx = 1;
	}
	if (tx) 
		iowrite16(MEMRX_PCINTACKK, &hw->memInfReg->MemPCIntAck);

	/* Acknowledge interrupt at PCMCIA level. */
	iowrite16(ioread16(&hw->memCCR->PCCSR) & 0xfffd, &hw->memCCR->PCCSR);

	if (tx || rx) {
		/* Perform the I/O retrieval in a tasklet, because the ppp_generic
		   may be called from a tasklet, but not from a hardware interrupt. */
		if (!hw->tasklet_pending) {
			hw->tasklet_pending = 1;
			tasklet_schedule(&hw->tasklet);
		}
	} else if (!rx_repeat) {
		if (hw->MemTX == &hw->memInfReg->MemTX_NEW) {
			printk(KERN_WARNING IPWIRELESS_PCCARD_NAME
					": No valid MemTX value - switching to the old MemTX register address.\n");
			hw->MemTX = &hw->memInfReg->MemTX_OLD;
			goto out;
		} else {
			printk(KERN_WARNING IPWIRELESS_PCCARD_NAME ": spurious interrupt!\n");
			hw->irq = irq;
			hw->removed = 1;
			disable_irq_nosync(irq);
		}
	}
out:
	return IRQ_HANDLED;
}

irqreturn_t ipwireless_interrupt(int irq, void *dev_id, struct pt_regs * regs)
{
	ipw_hardware_t *hw = (ipw_hardware_t *) dev_id;

	if (hw->hwVersion == HW_VERSION_1)
		return ipwireless_handle_v1_interrupt(irq, hw);
	else 
		return ipwireless_handle_v2_v3_interrupt(irq, hw);
}

static void send_packet(ipw_hardware_t * hw, int priority,
			ipw_tx_packet_t * packet)
{
	struct list_head *p = &hw->tx_queue[priority];

	spin_lock_irq(&hw->spinlock);
	list_add_tail(&packet->queue, p);
	hw->tx_queued = 1;
	/* If we happen to have got here as a result of processing from the do_io()
	   loop, then do_io() will detect this situation and do nothing. */
	do_io(hw);
	spin_unlock_irq(&hw->spinlock);
}

static void *create_packet(int packet_size,
			      u_char dest_addr,
			      u_char protocol,
			      packet_sent_callback_t
			      packet_sent_callback)
{
	ipw_tx_packet_t *packet = kzalloc(packet_size, GFP_ATOMIC);
	INIT_LIST_HEAD(&packet->queue);
	packet->dest_addr = dest_addr;
	packet->protocol = protocol;
	packet->packet_sent_callback = packet_sent_callback;
	packet->length = packet_size - sizeof(ipw_tx_packet_t);
	return packet;
}

void
ipwireless_send_packet(ipw_hardware_t * hw, unsigned int channelIdx,
		       u_char * data, unsigned int length,
		       ipw_packet_sent_callback_t callback,
		       void *callback_data)
{
	ipw_tx_packet_t *packet;
	unsigned int flags;

	local_irq_save(flags);
	packet = create_packet(sizeof(ipw_tx_packet_t) + length,
			       (u_char) (channelIdx + 1),
			       TL_PROTOCOLID_COM_DATA,
			       free_packet_and_callback);
	packet->external_callback = callback;
	packet->external_callback_data = callback_data;
	memcpy((u_char *) packet + sizeof(ipw_tx_packet_t), data, length);
	send_packet(hw, PRIO_DATA, packet);
	local_irq_restore(flags);
}

static void setControlLine(ipw_hardware_t * hw, int gfp_flag,
			   unsigned int channelIdx, int line, int state)
{
	ipw_control_packet_t *packet;
	packet= create_packet(sizeof(ipw_control_packet_t), (u_char) (channelIdx + 1),
				  TL_PROTOCOLID_COM_CTRL, free_packet);
	packet->packet.length = sizeof(ipw_control_packet_body_t);
	packet->body.sigNo = (u_char) line;
	packet->body.value = (u_char) (state == 0 ? 0 : 1);
	send_packet(hw, PRIO_CTRL, &packet->packet);
}

static void setDTR(ipw_hardware_t * hw, int priority,
		   unsigned int channelIdx, int state)
{
	if (state != 0)
		hw->control_lines[channelIdx] |= IPW_CONTROL_LINE_DTR;
	else
		hw->control_lines[channelIdx] &= ~IPW_CONTROL_LINE_DTR;

	setControlLine(hw, priority, channelIdx, ComCtrl_DTR, state);
}

static void setRTS(ipw_hardware_t * hw, int priority,
		   unsigned int channelIdx, int state)
{
	if (state != 0)
		hw->control_lines[channelIdx] |= IPW_CONTROL_LINE_RTS;
	else
		hw->control_lines[channelIdx] &= ~IPW_CONTROL_LINE_RTS;

	setControlLine(hw, priority, channelIdx, ComCtrl_RTS, state);
}

void ipwireless_setDTR(ipw_hardware_t * hw, unsigned int channelIdx,
		       int state)
{
	setDTR(hw, PRIO_CTRL, channelIdx, state);
}

void ipwireless_setRTS(ipw_hardware_t * hw, unsigned int channelIdx,
		       int state)
{
	setRTS(hw, PRIO_CTRL, channelIdx, state);
}

typedef struct ipw_setup_get_version_query_packet_t {
	ipw_tx_packet_t packet;
	TlSetupGetVersionQry body;
} ipw_setup_get_version_query_packet_t;

typedef struct ipw_setup_config_packet_t {
	ipw_tx_packet_t packet;
	TlSetupConfigMsg body;
} ipw_setup_config_packet_t;

typedef struct ipw_setup_config_done_packet_t {
	ipw_tx_packet_t packet;
	TlSetupConfigDoneMsg body;
} ipw_setup_config_done_packet_t;

typedef struct ipw_setup_open_packet_t {
	ipw_tx_packet_t packet;
	TlSetupOpenMsg body;
} ipw_setup_open_packet_t;

typedef struct ipw_setup_info_packet_t {
	ipw_tx_packet_t packet;
	TlSetupInfoMsg body;
} ipw_setup_info_packet_t;

typedef struct {
	ipw_tx_packet_t packet;
	TlSetupRebootMsgAck body;
} ipw_setup_reboot_msg_ack_t;

/* This handles the actual initialization of the card */
static void __handle_setup_get_version_rsp(ipw_hardware_t *hw)
{
	ipw_setup_config_packet_t *config_packet;
	ipw_setup_config_done_packet_t *config_done_packet;
	ipw_setup_open_packet_t *open_packet;
	ipw_setup_info_packet_t *info_packet;
	int port;
	unsigned int channelIdx;

	/* generate config packet */
	for (port = 1; port <= NL_NUM_OF_ADDRESSES; port++) {
		config_packet = create_packet(sizeof(ipw_setup_config_packet_t),
				ADDR_SETUP_PROT,
				TL_PROTOCOLID_SETUP,
				free_packet);
		config_packet->packet. length = sizeof(TlSetupConfigMsg);
		config_packet->body.sigNo = TL_SETUP_SIGNO_CONFIG_MSG;
		config_packet->body.portNo = port;
		config_packet->body.prioData = PRIO_DATA;
		config_packet->body.prioCtrl = PRIO_CTRL;
		send_packet(hw, PRIO_SETUP, &config_packet->packet);
	}
	config_done_packet = create_packet(sizeof(ipw_setup_config_done_packet_t),
			ADDR_SETUP_PROT,
			TL_PROTOCOLID_SETUP,
			free_packet);
	config_done_packet->packet.length = sizeof(TlSetupConfigDoneMsg);
	config_done_packet->body.sigNo = TL_SETUP_SIGNO_CONFIG_DONE_MSG;
	send_packet(hw, PRIO_SETUP, &config_done_packet->packet);

	/* generate open packet */
	for (port = 1; port <= NL_NUM_OF_ADDRESSES; port++) {
		open_packet = create_packet(sizeof(ipw_setup_open_packet_t),
				ADDR_SETUP_PROT,
				TL_PROTOCOLID_SETUP,
				free_packet);
		open_packet->packet.length = sizeof(TlSetupOpenMsg);
		open_packet->body.sigNo = TL_SETUP_SIGNO_OPEN_MSG;
		open_packet->body.portNo = port;
		send_packet(hw, PRIO_SETUP, &open_packet->packet);
	}
	for (channelIdx = 0; channelIdx < NL_NUM_OF_ADDRESSES; channelIdx++) {
		setDTR(hw, PRIO_SETUP, channelIdx, (hw->control_lines[channelIdx] & IPW_CONTROL_LINE_DTR) != 0);
		setRTS(hw, PRIO_SETUP, channelIdx, (hw->control_lines [channelIdx] & IPW_CONTROL_LINE_RTS) != 0);
	}
	/* For NDIS we assume that we are using sync PPP frames, for COM async. This 
	 * driver uses NDIS mode too. We don't bother with translation from async -> sync PPP. 
	 */
	info_packet = create_packet(sizeof(ipw_setup_info_packet_t),
			ADDR_SETUP_PROT,
			TL_PROTOCOLID_SETUP,
			free_packet);
	info_packet->packet.length = sizeof(TlSetupInfoMsg);
	info_packet->body.sigNo = TL_SETUP_SIGNO_INFO_MSG;
	info_packet->body.driverType = NDISWAN_DRIVER;
	info_packet->body.majorVersion = NDISWAN_DRIVER_MAJOR_VERSION;
	info_packet->body.minorVersion = NDISWAN_DRIVER_MINOR_VERSION;
	send_packet(hw, PRIO_SETUP, &info_packet->packet);

	/* Initialization is now complete, so we clear the 'to_setup' flag */
	hw->to_setup = 0;

}

static void handle_setup_get_version_rsp(ipw_hardware_t *hw, u_char vers_no)
{
	del_timer(&hw->setup_timer);
	hw->initializing = 0;
	printk(KERN_INFO IPWIRELESS_PCCARD_NAME ": card is ready.\n");

	if (vers_no == TL_SETUP_VERSION)
		__handle_setup_get_version_rsp(hw);
	else 
		printk(KERN_ERR
				IPWIRELESS_PCCARD_NAME
				": invalid hardware version no %u\n",
				(unsigned int) vers_no);
}

static void handle_received_SETUP_packet(ipw_hardware_t *hw, unsigned int address,
			     u_char *data, int len, int is_last)
{
	SETUP_RX_MSG *rx_msg = (SETUP_RX_MSG *) data;

	if (address != ADDR_SETUP_PROT) {
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": setup packet has bad address %d\n", address);
		return;
	}

	switch (rx_msg->sigNo) {
	case TL_SETUP_SIGNO_GET_VERSION_RSP:
		if (hw->to_setup) 
			handle_setup_get_version_rsp(hw, rx_msg->VersRspMsg.version);
		break;

	case TL_SETUP_SIGNO_OPEN_MSG:
		if (ipwireless_cs_debug) {
			unsigned int channelIdx = rx_msg->OpenMsg.portNo - 1;
			printk(KERN_INFO IPWIRELESS_PCCARD_NAME
			       ": OPEN_MSG [channel %u] reply received\n", channelIdx);
		}
		break;

	case TL_SETUP_SIGNO_INFO_MSG_ACK:
		if (ipwireless_cs_debug)
			printk(KERN_DEBUG IPWIRELESS_PCCARD_NAME
			       ": card successfully configured as driver type NDISWAN\n");
		break;

	case TL_SETUP_SIGNO_REBOOT_MSG:
		if (hw->to_setup) {
			printk(KERN_DEBUG IPWIRELESS_PCCARD_NAME
			       ": Ignoring REBOOT message since setup has not completed\n");
		} else {
			ipw_setup_reboot_msg_ack_t *packet;

			printk(KERN_DEBUG IPWIRELESS_PCCARD_NAME
			       ": Acknowledging REBOOT message\n");
			packet = create_packet(sizeof(ipw_setup_reboot_msg_ack_t),
					ADDR_SETUP_PROT, TL_PROTOCOLID_SETUP, free_packet);
			packet->packet.length = sizeof(TlSetupRebootMsgAck);
			packet->body.sigNo = TL_SETUP_SIGNO_REBOOT_MSG_ACK;
			send_packet(hw, PRIO_SETUP, &packet->packet);
			if (hw->reboot_callback != NULL)
				(hw->reboot_callback) (hw->reboot_callback_data);
		}
		break;

	default:
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": unknown setup message %u received\n",
		       (unsigned int) rx_msg->sigNo);
	}
}

static void do_setup_hardware(ipw_hardware_t * hw)
{
	ipw_setup_get_version_query_packet_t *ver_packet;

	if (hw->hwVersion == HW_VERSION_1) {
		/* Reset RX FIFO */
		outw(DCR_RXRESET, hw->base_port + IODCR);
		/* SB: Reset TX FIFO */
		outw(DCR_TXRESET, hw->base_port + IODCR);

		/* Enable TX and RX interrupts. */
		outw(IER_TXENABLED | IER_RXENABLED, hw->base_port + IOIER);
	} else {
		/* Set INTRACK bit (bit 0), which means we must explicitly acknowledge
		 * interrupts by clearing bit 2 of PCCSR. */
		u_short csr = ioread16(&hw->memCCR->PCCSR);
		csr |= 1;
		iowrite16(csr, &hw->memCCR->PCCSR);
	}

	ver_packet = create_packet(sizeof(ipw_setup_get_version_query_packet_t),
			ADDR_SETUP_PROT, TL_PROTOCOLID_SETUP, free_packet);
	ver_packet->body.sigNo = TL_SETUP_SIGNO_GET_VERSION_QRY;
	ver_packet->packet.length = sizeof(TlSetupGetVersionQry);

	send_packet(hw, PRIO_SETUP, &ver_packet->packet);

	/* The response to this version request is handled in handle_received_SETUP_packet */
}

static void do_close_hardware(ipw_hardware_t * hw)
{
	unsigned int irqn;

	if (hw->hwVersion == HW_VERSION_1) {
		/* Disable TX and RX interrupts. */
		outw(0, hw->base_port + IOIER);

		/* Acknowledge any outstanding interrupt requests */
		irqn = inw(hw->base_port + IOIR);
		if (irqn & IR_TXINTR)
			outw(IR_TXINTR, hw->base_port + IOIR);
		if (irqn & IR_RXINTR)
			outw(IR_RXINTR, hw->base_port + IOIR);
	}
}

ipw_hardware_t *ipwireless_hardware_create(struct ipw_config_t *config)
{
	int i;
	ipw_hardware_t *hw = kzalloc(sizeof(struct ipw_hardware_t), GFP_KERNEL);
	if (!hw)
		return NULL;

	hw->initializing = 1;
	hw->tx_ready = 1;
	memcpy(&hw->config, config, sizeof(ipw_config_t));
	for (i = 0; i < NL_NUM_OF_PRIORITIES; i++)
		INIT_LIST_HEAD(&hw->tx_queue[i]);

	hw->rx_bytes_queued = 0;
	INIT_LIST_HEAD(&hw->rx_queue);
	INIT_LIST_HEAD(&hw->rx_pool);

	spin_lock_init(&hw->spinlock);
	tasklet_init(&hw->tasklet, ipwireless_do_tasklet,
		     (unsigned long) hw);

	init_timer(&hw->setup_timer);
	hw->setup_timer.function = ipwireless_setup_timer;
	hw->setup_timer.data = (unsigned long) hw;

	INIT_WORK(&hw->work_rx, do_receive_data_work);

	hw->last_memtx_serial = (u_short) 0xffff;

	return hw;
}

void
ipwireless_init_hardware1(struct ipw_hardware_t *hw,
			  unsigned int base_port,
			  void IPWIRELESS_IOMEM * attrMemory,
			  void IPWIRELESS_IOMEM * commonMemory,
			  int isV2Card,
			  ipw_reboot_callback_t reboot_callback,
			  void *reboot_callback_data)
{
	hw->bad_interrupt_count = 0;
	if (hw->removed) {
		hw->removed = 0;
		enable_irq(hw->irq);
	}
	hw->base_port = base_port;
	hw->hwVersion = isV2Card ? HW_VERSION_2 : HW_VERSION_1;
	hw->llMTU = hw->hwVersion == HW_VERSION_1 ? LL_MTU_V1 : LL_MTU_V2;
	hw->memCCR = (MEMCCR IPWIRELESS_IOMEM *) ((u_short *) attrMemory + 0x200);
	hw->memInfReg = (MEMINFREG IPWIRELESS_IOMEM *) commonMemory;
	hw->MemTX = &hw->memInfReg->MemTX_NEW;
	hw->reboot_callback = reboot_callback;
	hw->reboot_callback_data = reboot_callback_data;
}

void ipwireless_init_hardware2(struct ipw_hardware_t *hw)
{
	hw->initializing = 1;
	hw->init_loops = 0;
	printk(KERN_INFO IPWIRELESS_PCCARD_NAME
	       ": waiting for card to start up...\n");
	ipwireless_setup_timer((unsigned long) hw);
}

static void ipwireless_setup_timer(unsigned long data)
{
	struct ipw_hardware_t *hw = (struct ipw_hardware_t *) data;

	hw->init_loops++;
	/* Give up after a certain number of retries */
	if (hw->init_loops == TL_SETUP_MAX_VERSION_QRY) {
		printk(KERN_INFO IPWIRELESS_PCCARD_NAME
		       ": card failed to start up!\n");
		hw->initializing = 0;
	} else {
		unsigned long flags;

		/* Do not attempt to write to the board if it is not present. */
		if (is_card_present(hw)) {
			/* Perform the I/O retrieval in a tasklet, because ppp_generic
			 * may be called from a tasklet, but not from a hardware interrupt. */
			hw->to_setup = 1;
			hw->tx_ready = 1;
			spin_lock_irqsave(&hw->spinlock, flags);
			if (!hw->tasklet_pending) {
				hw->tasklet_pending = 1;
				tasklet_schedule(&hw->tasklet);
			}
			spin_unlock_irqrestore(&hw->spinlock, flags);
		}

		hw->setup_timer.expires =
		    jiffies + (unsigned long) TL_SETUP_VERSION_QRY_TMO *HZ / 1000UL;
		add_timer(&hw->setup_timer);
	}
}

/* Stop any interrupts from executing so that, once this function returns,
 * other layers of the driver can be sure they won't get any more callbacks.
 * Thus must be called on a proper process context. */
void ipwireless_stop_interrupts(struct ipw_hardware_t *hw)
{
	if (!hw->shutting_down) {
		/* Tell everyone we are going down. */
		hw->shutting_down = 1;
		del_timer(&hw->setup_timer);

		/* Prevent the hardware from sending any more interrupts */
		do_close_hardware(hw);
	}
}

void ipwireless_hardware_free(ipw_hardware_t * hw)
{
	int i;
	struct list_head *p, *q;

	ipwireless_stop_interrupts(hw);

	flush_scheduled_work();

	for (i = 0; i < NL_NUM_OF_ADDRESSES; i++)
		if (hw->packet_assembler[i].packet != NULL)
			kfree(hw->packet_assembler[i].packet);

	for (i = 0; i < NL_NUM_OF_PRIORITIES; i++)
		list_for_each_safe(p, q, &hw->tx_queue[i]){
			ipw_tx_packet_t *packet = list_entry(p, ipw_tx_packet_t, queue);
			list_del_init(p);
			free_packet(hw, packet);
		}

	list_for_each_safe(p, q, &hw->rx_queue) {
		ipw_rx_packet_t *packet = list_entry(p, ipw_rx_packet_t, queue);
		list_del_init(p);
                kfree(packet);
        }

	list_for_each_safe(p, q, &hw->rx_pool) {
		ipw_rx_packet_t *packet = list_entry(p, ipw_rx_packet_t, queue);
		list_del_init(p);
		kfree(packet);
	}
	kfree(hw);
}

/* Associate the specified network with this hardware, so it will receive events
 * from it. */
void ipwireless_associate_network(struct ipw_hardware_t *hw,
				  struct ipw_network_t *network)
{
	hw->network = network;
}
